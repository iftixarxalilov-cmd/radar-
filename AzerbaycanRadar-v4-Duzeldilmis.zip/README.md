# Azərbaycan Radar v4 — Android

**Təkmilləşdirilmiş layihə mənbə kodu.** Bu arxiv APK deyil. GitHub Actions vasitəsilə APK yığılması üçün hazırlanıb. Bu mühitdə Android SDK olmadığından APK-nin yığılması və telefonda işləməsi hələ təsdiqlənməyib.

## Funksiyalar
- GPS məkan izləməsi və qaranlıq interfeys.
- OpenStreetMap/Overpass xəritəsində qeydə alınmış sabit radar nöqtələrindən avtomobil hərəkət istiqamətində olanları izləyir.
- Radarın **500 metr** və **100 metr** yaxınlığında səsli xəbərdarlıq. Proqram radarın 100 metrindən yaxın məsafədə başladılıbsa, iki xəbərdarlığı ardıcıl səsləndirmir.
- Yaxın yolun açıq `maxspeed` məlumatını GPS-lə təxmini uyğunlaşdırır; təsdiqlənən dəyişiklikləri səslə bildirir. İstiqaməti də nəzərə alır, lakin bu, rəsmi yol nişanının əvəzi deyil.
- **Geri • Arxa fon** tətbiqi arxa plana keçirir, izləmə davam edir; **Çıxış • Dayandır** GPS izləməsini və səsi dayandırır.
- Ekran sönəndə fəaliyyət üçün Android `foregroundServiceType="location"` və daimi bildiriş işlədilir.
- Xəritə uğursuz yüklənərsə, təkrar yoxlanır; hərəkət etdikdə və ya köhnəldikdə yenilənir.
- Tətbiqi yenidən açanda işləyən xidmətin canlı vəziyyəti göstərilir.

## GitHub-da APK düzəltmək
1. GitHub-da boş **AzerbaycanRadar** repozitoriyası yaradın və bu ZIP-in **içindəkiləri** (app, .github və Gradle faylları) repozitoriyanın kökünə yükləyin. ZIP faylının özünü ayrıca yükləmək APK yığmır.
2. **Actions → Azerbaycan Radar - APK yig → Run workflow** seçin. `push` zamanı da işə düşür.
3. Uğurlu nəticədə **Artifacts → Azerbaycan-Radar-v4-APK** faylını yükləyin.
4. Arxiv içindəki `app-debug.apk`-ni telefona quraşdırın. Əvvəlki APK-nin imzası fərqli olsa, köhnəsini silmək lazım gələ bilər (əvvəl şəxsi məlumatları qoruyun).

Android Studio üçün: Java 17, Android SDK 35, Gradle 8.9. `:app:assembleDebug`.

## Tələb olunan icazələr
- **Dəqiq məkan** — sürət və radar məsafəsi üçün.
- **Bildirişlər** (Android 13+) — işləyən izləmə bildirişinin göstərilməsi üçün.
- Telefonun məkan/GPS düyməsi aktiv olmalıdır. Xiaomi-də telefon parametrlərindən tətbiq üçün batareya məhdudiyyətini söndürmək bəzən lazımdır. Android sistemi bəzi hallarda xidməti yenə dayandıra bilər.

## Mühüm həqiqətlər və sərhədlər
- **Waze bazası istifadə edilmir.** Mənbə OpenStreetMap/Overpass-dir; xəritədə olmayan radar haqqında xəbərdarlıq mümkün deyil.
- Xəritə məlumatları natamam, köhnəlmiş və ya yanlışdırsa, xəbərdarlıq da səhv ola bilər. Sürət hədləri **təxmini**dir, real nişanlara və qanuna üstünlük verin. Hər radar istiqamətinin və yol üzrə gedişin təsdiqi yoxdur; yaxın paralel yolda radar səhv aşkar oluna bilər.
- İnternet lazımdır. Overpass serveri məşğul ola və sorğuya cavab verməyə bilər. Telefonun koordinatları sorğu üçün Overpass-a ötürülür. Proqramda reklam, hesab və yol tarixçəsi saxlanması yoxdur.
- **Qadın səsi zəmanətli deyil:** telefonda Azərbaycan dilində qadın TTS səsi varsa seçilir, yoxdursa əlçatan səs istifadə edilir. Səs işləmirsə, telefonun Mətnin səsə çevrilməsi (TTS) parametrlərini yoxlayın.
- Hərəkət olmadığı və ya GPS sürət ölçmədiyi halda yalnış bildirişlər verməmək üçün radar səsi səsləndirilmir.
- Yol üstündə yoxlama və APK-nin real cihazda işləmə sınağı aparılmayıb. Avtomobil idarə edərkən telefona baxmayın.

## v3-dən v4-ə dəyişikliklər
- 150 m əvəzinə **100 m** ikinci xəbərdarlıq.
- 500 m və 100 m ardıcıl səsin üst-üstə düşməsinin qarşısı.
- Xəritənin 2.5 km hərəkət etmədən yenilənməməsi problemi aradan qaldırılıb: 1.2 km və ya 6 dəqiqə əsasında, minimum 2 dəqiqə fasilə ilə yenilənir; səhv sorğular təkrar edilir.
- Xidmət işləyərkən interfeysə qayıdanda real status soruşulur; sadəcə sorğu üçün boş fon xidməti saxlanılmır.
- Daha təhlükəsiz yol-istiqamət uyğunlaşdırması və GPS provayderi sonradan aktiv ediləndə bərpa davranışı.

Məlumat lisenziyası: © OpenStreetMap contributors — https://www.openstreetmap.org/copyright
