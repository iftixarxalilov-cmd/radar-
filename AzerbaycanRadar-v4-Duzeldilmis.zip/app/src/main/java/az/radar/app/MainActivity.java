package az.radar.app;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int LOCATION_CODE = 21;
    private static final int NOTIFICATION_CODE = 22;
    private static final int BG = Color.rgb(10, 17, 28);
    private static final int WHITE = Color.rgb(238, 246, 255);
    private static final int SOFT = Color.rgb(169, 188, 203);
    private static final int GREEN = Color.rgb(44, 230, 166);
    private static final int RED = Color.rgb(248, 76, 94);
    private TextView gps, map, voice, distance, speed, limit, count, state;
    private Button startButton;
    private boolean receiverRegistered = false;
    private boolean active = false;

    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!RadarService.ACTION_STATUS.equals(intent.getAction())) return;
            active = intent.getBooleanExtra("active", false);
            state.setText(active ? "● İZLƏMƏ AKTİVDİR" : "○ İZLƏMƏ DAYANIB");
            state.setTextColor(active ? GREEN : SOFT);
            gps.setText(intent.getStringExtra("gps"));
            map.setText(intent.getStringExtra("map"));
            voice.setText(intent.getStringExtra("voice"));
            distance.setText(intent.getStringExtra("distance"));
            speed.setText(intent.getIntExtra("speed", 0) + " km/saat");
            int value = intent.getIntExtra("limit", -1);
            limit.setText(value > 0 ? value + " km/saat" : "Məlum deyil");
            count.setText(String.valueOf(intent.getIntExtra("count", 0)));
            startButton.setText(active ? "İZLƏMƏ DAVAM EDİR" : "İZLƏMƏNİ BAŞLAT");
        }
    };

    @Override protected void onCreate(Bundle stateBundle) {
        super.onCreate(stateBundle);
        buildUi();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(RadarService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(statusReceiver, filter);
        receiverRegistered = true;
        // Restore the actual live service status when the screen is reopened.
        try {
            startService(new Intent(this, RadarService.class)
                    .setAction(RadarService.ACTION_REQUEST_STATUS));
        } catch (IllegalStateException | SecurityException ignored) {
            // Service not available; the default stopped state remains on screen.
        }
    }

    @Override protected void onStop() {
        if (receiverRegistered) {
            unregisterReceiver(statusReceiver);
            receiverRegistered = false;
        }
        super.onStop();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));
        scroll.addView(root);
        setContentView(scroll);

        TextView flag = label("🇦🇿  AZƏRBAYCAN RADAR", 23, WHITE, true);
        flag.setGravity(Gravity.CENTER);
        root.addView(flag, lp(0, 14));
        TextView subtitle = label("Yol təhlükəsizliyi üçün GPS köməkçisi", 13, SOFT, false);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, lp(0, 20));
        TextView status = label("○ İZLƏMƏ DAYANIB", 17, SOFT, true);
        status.setGravity(Gravity.CENTER);
        status.setBackground(box(Color.rgb(17, 34, 44), GREEN));
        status.setPadding(dp(12), dp(15), dp(12), dp(15));
        root.addView(status, lp(0, 20));
        this.state = status;

        LinearLayout dash = new LinearLayout(this);
        dash.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(dash, lp(0, 16));
        dash.addView(metric("SÜRƏT", "0 km/saat", false), new LinearLayout.LayoutParams(0, dp(120), 1));
        View separator = new View(this);
        dash.addView(separator, new LinearLayout.LayoutParams(dp(9), 1));
        dash.addView(metric("XƏRİTƏ HƏDDİ", "Məlum deyil", true), new LinearLayout.LayoutParams(0, dp(120), 1));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(18), dp(20), dp(18));
        card.setBackground(box(Color.rgb(19, 30, 44), 0));
        root.addView(card, lp(0, 16));
        card.addView(label("📡  ƏN YAXIN RADAR", 13, SOFT, true));
        distance = label("—", 42, WHITE, true);
        distance.setPadding(0, dp(7), 0, dp(6));
        card.addView(distance);
        LinearLayout cameraRow = new LinearLayout(this);
        cameraRow.setOrientation(LinearLayout.HORIZONTAL);
        cameraRow.addView(label("12 km ətrafında radar nöqtələri: ", 12, SOFT, false));
        count = label("0", 12, GREEN, true);
        cameraRow.addView(count);
        card.addView(cameraRow);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(16), dp(15), dp(16), dp(15));
        info.setBackground(box(Color.rgb(16, 28, 40), 0));
        root.addView(info, lp(0, 18));
        gps = label("GPS gözlənilir", 15, GREEN, true);
        map = label("Xəritə yüklənməyib", 13, SOFT, false);
        voice = label("Səs hazırlanır", 13, SOFT, false);
        info.addView(gps, lp(0, 10));
        info.addView(map, lp(0, 10));
        info.addView(voice);

        startButton = actionButton("İZLƏMƏNİ BAŞLAT", GREEN, BG);
        root.addView(startButton, lp(0, 12));
        startButton.setOnClickListener(v -> startTracking());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actions, lp(0, 15));
        Button back = actionButton("GERİ • ARXA FON", Color.rgb(37, 54, 70), WHITE);
        actions.addView(back, new LinearLayout.LayoutParams(0, dp(58), 1));
        back.setOnClickListener(v -> moveTaskToBack(true));
        View gap = new View(this);
        actions.addView(gap, new LinearLayout.LayoutParams(dp(9), 1));
        Button exit = actionButton("ÇIXIŞ • DAYANDIR", RED, Color.WHITE);
        actions.addView(exit, new LinearLayout.LayoutParams(0, dp(58), 1));
        exit.setOnClickListener(v -> {
            active = false;
            Intent stop = new Intent(this, RadarService.class).setAction(RadarService.ACTION_STOP);
            startService(stop);
            this.state.setText("○ İZLƏMƏ DAYANIB");
            this.state.setTextColor(SOFT);
            startButton.setText("İZLƏMƏNİ BAŞLAT");
        });

        TextView note = label("⚠ Xəbərdarlıqlar OpenStreetMap məlumatlarından hesablanır; " +
                "bütün radarlar və sürət hədləri xəritədə olmaya bilər. " +
                "Yol nişanlarına üstünlük verin. Məlumat üçün internet tələb olunur. " +
                "© OpenStreetMap contributors • openstreetmap.org/copyright", 12, SOFT, false);
        note.setLineSpacing(dp(3), 1f);
        root.addView(note, lp(0, 0));
    }

    private LinearLayout metric(String title, String initial, boolean second) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER);
        block.setPadding(dp(6), dp(8), dp(6), dp(8));
        block.setBackground(box(Color.rgb(19, 30, 44), 0));
        TextView caption = label(title, 12, SOFT, true);
        caption.setGravity(Gravity.CENTER);
        block.addView(caption);
        TextView value = label(initial, second ? 17 : 23, second ? RED : WHITE, true);
        value.setGravity(Gravity.CENTER);
        value.setPadding(0, dp(12), 0, 0);
        block.addView(value);
        if (second) limit=value; else speed=value;
        return block;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(color);
        text.setTextSize(size);
        text.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return text;
    }

    private Button actionButton(String text, int background, int foreground) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(foreground);
        button.setBackground(box(background, 0));
        button.setMinHeight(dp(56));
        return button;
    }

    private GradientDrawable box(int color, int border) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(16));
        if (border != 0) drawable.setStroke(dp(1), border);
        return drawable;
    }

    private LinearLayout.LayoutParams lp(int top, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(top);
        params.bottomMargin = dp(bottom);
        return params;
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void startTracking() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION }, LOCATION_CODE);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_CODE);
            // Location tracking does not depend on notification permission.
        }
        Intent start = new Intent(this, RadarService.class).setAction(RadarService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(start);
            else startService(start);
            state.setText("● GPS BAŞLADILIR");
            state.setTextColor(GREEN);
        } catch (SecurityException | IllegalStateException e) {
            gps.setText("İzləmə başlamadı: məkan icazəsini və GPS-i yoxlayın");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_CODE) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                startTracking();
            } else gps.setText("Dəqiq yer icazəsi tələb olunur. Parametrlərdən 'Dəqiq yer'i aktiv edin.");
        }
    }

    @Override public void onBackPressed() {
        moveTaskToBack(true);
    }
}
