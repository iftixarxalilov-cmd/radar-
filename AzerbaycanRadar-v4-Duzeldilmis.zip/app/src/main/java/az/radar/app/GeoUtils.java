package az.radar.app;

import android.location.Location;
import java.util.List;

final class GeoUtils {
    private GeoUtils() {}

    static double distance(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }

    static double bearing(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[2];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[1];
    }

    static double angleDelta(double a, double b) {
        double d = Math.abs((a - b + 540) % 360 - 180);
        return Math.abs(d);
    }

    // Short-range road matching: nearest road segment with heading compatibility.
    // Opposite travel directions on a two-way road are both accepted.
    static double roadDistanceMeters(Location fix, List<OverpassClient.Point> points) {
        if (points == null || points.size() < 2) return Double.MAX_VALUE;
        double lat = fix.getLatitude(), lon = fix.getLongitude();
        double latScale = 111132.0;
        double lonScale = Math.cos(Math.toRadians(lat)) * 111320.0;
        boolean directionKnown = fix.hasBearing() && fix.hasSpeed() && fix.getSpeed() >= 2.8f;
        double best = Double.MAX_VALUE;
        for (int i = 0; i + 1 < points.size(); i++) {
            OverpassClient.Point a = points.get(i), b = points.get(i + 1);
            if (directionKnown) {
                double segHeading = bearing(a.lat, a.lon, b.lat, b.lon);
                double delta = angleDelta(fix.getBearing(), segHeading);
                if (Math.min(delta, 180 - delta) > 42) continue;
            }
            double ax = (a.lon - lon) * lonScale, ay = (a.lat - lat) * latScale;
            double bx = (b.lon - lon) * lonScale, by = (b.lat - lat) * latScale;
            double dx = bx - ax, dy = by - ay;
            double denom = dx * dx + dy * dy;
            double t = denom == 0 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / denom));
            double px = ax + dx * t, py = ay + dy * t;
            best = Math.min(best, Math.hypot(px, py));
        }
        return best;
    }
}
