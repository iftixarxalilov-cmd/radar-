package az.radar.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** The radar data source is OpenStreetMap/Overpass; it is NOT a Waze integration. */
final class OverpassClient {
    private static final String[] ENDPOINTS = {
            "https://overpass.kumi.systems/api/interpreter",
            "https://overpass-api.de/api/interpreter"
    };
    static final class Point {
        final double lat, lon;
        Point(double lat, double lon) { this.lat=lat; this.lon=lon; }
    }
    static final class Camera {
        final String id;
        final double lat, lon;
        Camera(String id, double lat, double lon) { this.id=id; this.lat=lat; this.lon=lon; }
    }
    static final class Road {
        final int speedLimit;
        final List<Point> geometry;
        Road(int speedLimit, List<Point> geometry) {
            this.speedLimit=speedLimit; this.geometry=geometry;
        }
    }
    static final class Result {
        final List<Camera> cameras;
        final List<Road> roads;
        Result(List<Camera> cameras, List<Road> roads) {
            this.cameras=cameras; this.roads=roads;
        }
    }

    static Result fetch(double latitude, double longitude) throws Exception {
        // One bounded query: cameras for 12km, tagged limits for 3km.
        // OSM may be incomplete. Do not treat it as an official enforcement database.
        String center = latitude + "," + longitude;
        String query = "[out:json][timeout:25];(" +
                "node[\"highway\"=\"speed_camera\"](around:12000," + center + ");" +
                "node[\"enforcement\"=\"maxspeed\"](around:12000," + center + ");" +
                "way[\"highway\"][\"maxspeed\"](around:3000," + center + ");" +
                ");out center geom;";
        Exception last = null;
        for (String endpoint : ENDPOINTS) {
            try { return parse(request(endpoint, query)); }
            catch (Exception e) { last = e; }
        }
        throw last != null ? last : new IllegalStateException("Xəritə xidməti əlçatan deyil");
    }

    private static String request(String endpoint, String query) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(35000);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        connection.setRequestProperty("User-Agent", "AzerbaycanRadar/4.0 (OSM-community-client)");
        byte[] body = ("data=" + URLEncoder.encode(query, "UTF-8")).getBytes(StandardCharsets.UTF_8);
        try {
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }
            int status = connection.getResponseCode();
            if (status != 200) throw new IllegalStateException("Xəritə HTTP " + status);
            try (InputStream in = connection.getInputStream(); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) {
                    if (bytes.size() + n > 6_000_000) throw new IllegalStateException("Xəritə cavabı çox böyükdür");
                    bytes.write(buffer, 0, n);
                }
                return bytes.toString("UTF-8");
            }
        } finally {
            connection.disconnect();
        }
    }

    private static Result parse(String json) throws JSONException {
        JSONArray elements = new JSONObject(json).getJSONArray("elements");
        List<Camera> cameras = new ArrayList<>();
        List<Road> roads = new ArrayList<>();
        for (int i=0; i<elements.length(); i++) {
            JSONObject item = elements.optJSONObject(i);
            if (item == null) continue;
            JSONObject tags = item.optJSONObject("tags");
            if (tags == null) continue;
            String type = item.optString("type", "");
            String highway = tags.optString("highway", "");
            String enforcement = tags.optString("enforcement", "");
            boolean isCamera = "speed_camera".equals(highway) || "maxspeed".equals(enforcement);
            if (isCamera) {
                JSONObject center = item.optJSONObject("center");
                JSONObject coord = "node".equals(type) ? item : center;
                if (coord != null && coord.has("lat") && coord.has("lon")) {
                    double lat = coord.optDouble("lat", 1000), lon = coord.optDouble("lon", 1000);
                    if (Math.abs(lat) <= 90 && Math.abs(lon) <= 180) {
                        boolean duplicate = false;
                        for (Camera c: cameras) {
                            if (GeoUtils.distance(c.lat, c.lon, lat, lon) < 45) { duplicate=true; break; }
                        }
                        if (!duplicate) cameras.add(new Camera(type + ":" + item.optLong("id"), lat, lon));
                    }
                }
            }
            if ("way".equals(type) && !highway.isEmpty() && !"speed_camera".equals(highway)) {
                int limit = parseSpeed(tags.optString("maxspeed", ""));
                JSONArray geometry = item.optJSONArray("geometry");
                if (limit <= 0 || geometry == null || geometry.length() < 2) continue;
                List<Point> points = new ArrayList<>();
                for (int k=0;k<geometry.length();k++) {
                    JSONObject p=geometry.optJSONObject(k);
                    if (p != null) points.add(new Point(p.optDouble("lat"),p.optDouble("lon")));
                }
                if (points.size() >= 2) roads.add(new Road(limit, points));
            }
        }
        return new Result(Collections.unmodifiableList(cameras), Collections.unmodifiableList(roads));
    }

    // Use only explicit numeric km/h values; no inferred or conditional limits.
    private static int parseSpeed(String raw) {
        if (raw == null) return -1;
        String value = raw.trim().toLowerCase(java.util.Locale.ROOT);
        if (!value.matches("[0-9]{1,3}(\\s*(km/h|kmh|kph))?")) return -1;
        try {
            int speed = Integer.parseInt(value.replaceAll("[^0-9]", ""));
            return speed >= 10 && speed <= 140 ? speed : -1;
        } catch (NumberFormatException ignored) { return -1; }
    }
}
