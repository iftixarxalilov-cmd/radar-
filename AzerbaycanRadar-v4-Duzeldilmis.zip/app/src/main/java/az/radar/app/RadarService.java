package az.radar.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RadarService extends Service implements TextToSpeech.OnInitListener {
    static final String ACTION_START = "az.radar.app.START";
    static final String ACTION_STOP = "az.radar.app.STOP";
    static final String ACTION_STATUS = "az.radar.app.STATUS";
    static final String ACTION_REQUEST_STATUS = "az.radar.app.REQUEST_STATUS";
    private static final String CHANNEL = "radar_gps";
    private static final int NOTIFICATION_ID = 1407;
    // Refresh while driving or periodically while waiting; never make a tight retry loop.
    private static final long MIN_FETCH_INTERVAL = 120_000L;
    private static final long MAX_MAP_AGE = 6 * 60_000L;
    private static final double REFRESH_DISTANCE = 1200.0;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Map<String, Integer> warned = new HashMap<>();
    private LocationManager locationManager;
    private LocationListener locationListener;
    private volatile OverpassClient.Result map = new OverpassClient.Result(new ArrayList<>(), new ArrayList<>());
    private Location currentLocation;
    private Location requestedAt;
    private long lastRequestTime = 0;
    private boolean fetching = false;
    private long lastSuccessfulFetchTime = 0;
    private boolean started = false;
    private TextToSpeech tts;
    private boolean speechReady = false;
    private String speechNote = "Səs hazırlanır";
    private String gpsStatus = "GPS gözlənilir";
    private String mapStatus = "Xəritə yüklənir";
    private int shownLimit = -1;
    private int pendingLimit = -1;
    private int pendingLimitCount = 0;
    private String cameraDistance = "—";
    private int speedKmh = 0;
    private long lastNotificationUpdate = 0;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        tts = new TextToSpeech(getApplicationContext(), this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopTracking();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_REQUEST_STATUS.equals(action)) {
            report();
            // A status read must not leave behind a background service when tracking is off.
            if (!started) {
                stopSelfResult(startId);
                return START_NOT_STICKY;
            }
            return START_STICKY;
        }
        if (!started) {
            try {
                startForeground(NOTIFICATION_ID, buildNotification("GPS siqnalı gözlənilir"));
                started = true;
                beginGps();
            } catch (SecurityException e) {
                gpsStatus = "GPS icazəsi və ya fon xidməti icazəsi çatmır";
                report();
                stopSelfResult(startId);
                return START_NOT_STICKY;
            }
        }
        report();
        return START_STICKY;
    }

    private void createChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null && Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Radar izləmə", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("GPS radar izləməsi aktivdir");
            manager.createNotificationChannel(c);
        }
    }

    private Notification buildNotification(String content) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int immutable = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, immutable);
        Intent stop = new Intent(this, RadarService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 1, stop, immutable);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(az.radar.app.R.drawable.ic_radar)
                .setContentTitle("Azərbaycan Radar • izləmə aktivdir")
                .setContentText(content)
                .setContentIntent(pending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dayandır", stopPending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void beginGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gpsStatus = "Dəqiq yer icazəsi verilməyib";
            report();
            return;
        }
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
            gpsStatus = "GPS xidməti yoxdur";
            report();
            return;
        }
        locationListener = new LocationListener() {
            @Override public void onLocationChanged(Location location) { onFix(location); }
            @Override public void onProviderDisabled(String provider) { gpsStatus = "GPS söndürülüb"; report(); }
            @Override public void onProviderEnabled(String provider) { gpsStatus = "GPS siqnalı gözlənilir"; report(); }
            @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
        };
        boolean any = false;
        try {
            // Register even if GPS is temporarily switched off: the listener can recover.
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000L, 0f, locationListener);
            any = true;
        } catch (IllegalArgumentException ignored) {
            // GPS hardware is optional on some devices.
        } catch (SecurityException e) { gpsStatus = "GPS icazəsi çatmır"; }
        try {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 5f, locationListener);
            any = true;
        } catch (IllegalArgumentException ignored) {
            // Network location provider may not exist.
        } catch (SecurityException e) { gpsStatus = "Məkan icazəsi çatmır"; }
        if (any) {
            boolean gpsEnabled = false, networkEnabled = false;
            try { gpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER); }
            catch (IllegalArgumentException ignored) { }
            try { networkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER); }
            catch (IllegalArgumentException ignored) { }
            if (!gpsEnabled && !networkEnabled) gpsStatus = "Telefonun məkan xidmətini aktiv edin";
        }
        if (!any) gpsStatus = "Telefonun məkan xidmətini aktiv edin";
        report();
    }

    private void onFix(Location location) {
        if (!started) return;
        if (location.hasAccuracy() && location.getAccuracy() > 85f) {
            gpsStatus = "GPS dəqiqliyi zəifdir (" + Math.round(location.getAccuracy()) + " m)";
            report();
            return;
        }
        // Discard old fixes that could create false alarms.
        long fixAge = SystemClock.elapsedRealtimeNanos() - location.getElapsedRealtimeNanos();
        if (fixAge < 0 || fixAge > 20_000_000_000L) return;
        currentLocation = location;
        gpsStatus = "GPS: Aktiv" + (location.hasAccuracy() ? " (±" + Math.round(location.getAccuracy()) + " m)" : "");
        speedKmh = location.hasSpeed() ? Math.max(0, (int) Math.round(location.getSpeed() * 3.6)) : 0;
        fetchMapIfNeeded(location);
        analyzeRadar(location);
        analyzeRoadLimit(location);
        report();
        long now = SystemClock.elapsedRealtime();
        if (now - lastNotificationUpdate > 15000) {
            lastNotificationUpdate = now;
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(NOTIFICATION_ID,
                    buildNotification("Sürət: " + speedKmh + " km/saat • Radar: " + cameraDistance));
        }
    }

    private void fetchMapIfNeeded(Location fix) {
        long now = SystemClock.elapsedRealtime();
        if (fetching) return;
        if (lastRequestTime != 0 && now - lastRequestTime < MIN_FETCH_INTERVAL) return;
        boolean moved = requestedAt == null || GeoUtils.distance(
                requestedAt.getLatitude(), requestedAt.getLongitude(),
                fix.getLatitude(), fix.getLongitude()) >= REFRESH_DISTANCE;
        boolean expired = lastSuccessfulFetchTime == 0 ||
                now - lastSuccessfulFetchTime >= MAX_MAP_AGE;
        if (!moved && !expired) return;
        fetching = true;
        lastRequestTime = now;
        requestedAt = new Location(fix);
        mapStatus = "OSM xəritəsi yenilənir";
        double lat = fix.getLatitude(), lon = fix.getLongitude();
        worker.execute(() -> {
            try {
                OverpassClient.Result result = OverpassClient.fetch(lat, lon);
                new android.os.Handler(getMainLooper()).post(() -> {
                    if (!started) return;
                    map = result;
                    fetching = false;
                    lastSuccessfulFetchTime = SystemClock.elapsedRealtime();
                    mapStatus = "OSM: " + result.cameras.size() + " radar nöqtəsi";
                    if (currentLocation != null) {
                        analyzeRadar(currentLocation);
                        analyzeRoadLimit(currentLocation);
                    }
                    report();
                });
            } catch (Exception err) {
                new android.os.Handler(getMainLooper()).post(() -> {
                    fetching = false;
                    mapStatus = "Xəritə yüklənmədi (internet/xidmət)";
                    report();
                });
            }
        });
    }

    private void analyzeRadar(Location fix) {
        List<OverpassClient.Camera> cameras = map.cameras;
        OverpassClient.Camera closest = null;
        double minDistance = Double.MAX_VALUE;
        Set<String> present = new HashSet<>();
        // Do not announce cameras while stationary / without evidence of travel.
        boolean moving = fix.hasSpeed() && fix.getSpeed() >= 1.7f; // roughly 6 km/h
        for (OverpassClient.Camera cam : cameras) {
            present.add(cam.id);
            double meters = GeoUtils.distance(fix.getLatitude(), fix.getLongitude(), cam.lat, cam.lon);
            boolean approaching = true;
            // Discard cameras clearly behind the current travel direction.
            if (fix.hasBearing() && speedKmh > 10 && meters > 35) {
                double direction = GeoUtils.bearing(fix.getLatitude(), fix.getLongitude(), cam.lat, cam.lon);
                approaching = GeoUtils.angleDelta(fix.getBearing(), direction) <= 75;
            }
            if (approaching && meters < minDistance) {
                minDistance = meters;
                closest = cam;
            }
            // Re-arm only after leaving the same radar's vicinity.
            if (meters > 900) {
                warned.remove(cam.id);
                continue;
            }
            if (!approaching || !moving) continue;
            int stage = warned.containsKey(cam.id) ? warned.get(cam.id) : 0;
            if (meters <= 100 && stage < 2) {
                // If started inside 100m, announce only the urgent stage.
                say("Diqqət! Radar təxminən 100 metr irəlidədir.", "radar100_" + cam.id, true);
                stage = 2;
            } else if (meters <= 500 && stage < 1) {
                say("Diqqət! Radar təxminən 500 metr irəlidədir.", "radar500_" + cam.id, true);
                stage = 1;
            }
            if (stage > 0) warned.put(cam.id, stage);
        }
        warned.keySet().retainAll(present);
        cameraDistance = closest == null ? "Məlumat yoxdur" : Math.round(minDistance) + " m";
    }

    private void analyzeRoadLimit(Location fix) {
        // Conservative approximation only: may match the wrong adjacent road.
        double closestMeters = Double.MAX_VALUE;
        int bestLimit = -1;
        for (OverpassClient.Road road : map.roads) {
            double meters = GeoUtils.roadDistanceMeters(fix, road.geometry);
            if (meters < closestMeters) {
                closestMeters = meters;
                bestLimit = road.speedLimit;
            }
        }
        if (closestMeters > 24 || (fix.hasAccuracy() && fix.getAccuracy() > 24f)) bestLimit = -1;
        if (bestLimit != pendingLimit) {
            pendingLimit = bestLimit;
            pendingLimitCount = 1;
        } else {
            pendingLimitCount++;
        }
        if (pendingLimitCount < 3 || shownLimit == pendingLimit) return;
        shownLimit = pendingLimit;
        if (shownLimit > 0 && speedKmh > 3) {
            say("Xəritəyə görə təxmini sürət həddi saatda " + shownLimit + " kilometrdir.",
                    "limit_" + shownLimit + "_" + SystemClock.elapsedRealtime(), false);
        }
    }

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) {
            speechNote = "Səs mühərriki işləmir";
            report();
            return;
        }
        Locale az = new Locale("az", "AZ");
        int result = tts.setLanguage(az);
        if (result < TextToSpeech.LANG_AVAILABLE) {
            speechNote = "AZ səsi yoxdur, telefonun standart səsi seçilib";
            tts.setLanguage(Locale.getDefault());
        } else {
            speechNote = "Azərbaycan dili səsi aktiv";
            // Female Azerbaijani voices are chosen only if installed; not guaranteed.
            Set<Voice> voices = tts.getVoices();
            if (voices != null) for (Voice v : voices) {
                if (v.getLocale() != null && "az".equals(v.getLocale().getLanguage()) &&
                        v.getName().toLowerCase(Locale.ROOT).contains("female")) {
                    tts.setVoice(v);
                    speechNote = "Azərbaycan qadın səsi aktiv";
                    break;
                }
            }
        }
        tts.setSpeechRate(0.94f);
        tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
        speechReady = true;
        report();
    }

    private void say(String text, String utteranceId, boolean priority) {
        if (speechReady && tts != null) {
            tts.speak(text, priority ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                    null, utteranceId);
        }
    }

    private void report() {
        Intent update = new Intent(ACTION_STATUS).setPackage(getPackageName());
        update.putExtra("active", started);
        update.putExtra("gps", gpsStatus);
        update.putExtra("map", mapStatus);
        update.putExtra("count", map.cameras.size());
        update.putExtra("distance", cameraDistance);
        update.putExtra("speed", speedKmh);
        update.putExtra("limit", shownLimit);
        update.putExtra("voice", speechNote);
        sendBroadcast(update);
    }

    private void stopTracking() {
        started = false;
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (SecurityException ignored) {}
        }
        locationListener = null;
        fetching = false;
        if (tts != null) tts.stop();
        stopForeground(STOP_FOREGROUND_REMOVE);
        report();
    }

    @Override public void onDestroy() {
        stopTracking();
        if (tts != null) { tts.shutdown(); tts = null; }
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
